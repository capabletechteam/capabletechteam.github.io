import { dev } from '$app/environment'

export const title = 'capabletechteam'
export const description = 'capabletechteam site for nerds'
export const url = dev ? 'http://localhost:5173/' : 'https://joyofcode.xyz/'
